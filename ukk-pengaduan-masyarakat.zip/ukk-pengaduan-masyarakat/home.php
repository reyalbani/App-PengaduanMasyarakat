<?php
session_start();
// koneksi ke database
include('koneksi.php');

if (!isset($_SESSION['user']))
{
    echo "<script>alert('Anda harus login');</script>";
    echo "<script>location='login.php';</script>";
    header('location:login.php');
    exit();
}  

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengaduan Masyarakat</title>
    <link rel="stylesheet" href="bootstrap-5.3.2-dist/css/bootstrap.css">
    <link rel="stylesheet" href="style.css">
    <!-- <link rel="stylesheet" href="bootstrap-5.3.2-dist/css/bootstrap.css"> -->
</head>
<body>

    <?php include('navbar.php'); ?>
    <div class="container">
        <div class="weclome">
        <h1 class="mt-3">Selamat Datang <?php echo htmlentities($_SESSION['user']['username']); ?></h1>

        <table class="mt-4">
        <!-- <tr>
            <td><h4>Jumlah Laporan yang telah dilaporkan</h4></td>
            <td><h4>:</h4></td>
        </tr>
        <tr>
            <td><h4>Jumlah Laporan yang telah ditangani</h4></td>
            <td><h4>:</h4></td> -->
        </tr>
    </table>
    </div>
    <div class="content mt-3">
    <a class="btn btn-primary mb-3" href="tambahPengaduan.php">Buat Laporan</a>
    <table class="table-1 mb-5">
		<tr>
			<th style="width:2%">No</th>
			<th>Laporan</th>
			<th>Foto</th>
            <th>Tanggapan</th>
            <th>Tanggal</th>
			<th>Status</th>
            <th>Aksi</th>
		</tr>
        <?php $nomor=1 ?>
        <?php $user_id=$_SESSION['user']['nik']?>
        <!-- $ambil=$koneksi->query("SELECT * FROM pengaduan INNER JOIN tanggapan ON pengaduan.id_pengaduan = tanggapan.id_pengaduan WHERE nik = $user_id"); -->
        <?php $ambil=$koneksi->query("SELECT * FROM pengaduan LEFT JOIN tanggapan ON tanggapan.id_pengaduann = pengaduan.id_pengaduan WHERE nik = $user_id ORDER BY tgl_pengaduan DESC");?>
                      <?php while($pecah = $ambil-> fetch_assoc()){?> 
                        <tr>
                          <td class="py-1">
                          <?php echo $nomor ?>
                          </td>
                          <td class="py-1">
                          <?php echo $pecah['isi_laporan'];?>
                          </td>
                          <td>
                          <img src="foto_produk/<?php echo $pecah['foto'];?>" width="400">
                          </td>
                          <td>  
                          <?php if($pecah['status']=="0") {?>
                           belum dibalas oleh petugas
                          <?php } else if($pecah['status']=="proses") { ?>
                            <?php echo $pecah['tanggapan'];?>
                            <?php } else if($pecah['status']=="selesai") { ?>
                                <?php echo $pecah['tanggapan'];?>
                            <?php } ?>
                          </td> 
                          <td class="py-1">
                          <?php echo $pecah['tgl_pengaduan'];?>
                          </td>
                          <td>
                          <?php if($pecah['status']=="0") {?>
                            belum dibalas petugas
                          <?php } else if($pecah['status']=="proses") { ?>
                                    proses penyelesaian
                            <?php } else if($pecah['status']=="selesai") { ?>
                                selesai
                            <?php } ?>
                          </td> 
                          <td>
                           <a class="btn btn-primary" href="readPengaduan.php?id=<?php echo $pecah['id_pengaduan']; ?>">Lihat</a>
                           <a class="btn btn-warning" href="editPengaduan.php?id=<?php echo $pecah['id_pengaduan']; ?>">Edit</a>
                           <a class="btn btn-danger" href="deletePengaduan.php?id=<?php echo $pecah['id_pengaduan']; ?>">Delete</a>
                          </td> 
                        </tr>
                        <tr>
                        <?php $nomor++ ?>
                        <?php } ?>
	</table>
    </div>
    </div>

    <script src="bootstrap-5.3.2-dist/js/bootstrap.bundle.js"></script>
    <script src="bootstrap-5.3.2-dist/bootstrap.bundle.min.js"></script>
</body>
</html>