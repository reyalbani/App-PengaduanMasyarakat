<?php 
session_start();
include('koneksi.php');

if (!isset($_SESSION['user']))
{
    echo "<script>alert('Anda harus login');</script>";
    echo "<script>location='login.php';</script>";
    header('location:login.php');
    exit();
}   

$id_pengaduan = $_GET['id'];

$ambil1 = $koneksi->query("SELECT * FROM pengaduan WHERE id_pengaduan = $id_pengaduan");
$detailPetugas = $ambil1->fetch_assoc();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengaduan Masyarakat</title>
    <link rel="stylesheet" href="bootstrap-5.3.2-dist/css/bootstrap.css">
    <link rel="stylesheet" href="bootstrap-5.3.2-dist/css/bootstrap-grid.css">
    <link rel="stylesheet" href="bootstrap-5.3.2-dist/css/bootstrap-grid.min.css">
    <link rel="stylesheet" href="style.css">
    <!-- <link rel="stylesheet" href="bootstrap-5.3.2-dist/css/bootstrap.css"> -->
</head>
<body>

    <?php include('navbar.php'); ?>
    <div class="container">
        <div class="form-group">
        <h2 class="mt-3">Buat Pengaduan</h2>
        <form method="post" enctype="multipart/form-data">
  <label class="mt-3">Isi Laporan</label>
  <input class="form-control" type="text" name="isi_laporan" value="<?php echo $detailPetugas['isi_laporan']; ?>" />
  <label class="mt-3">Foto</label>
  <div class="form-group">
        <img src="foto_produk/<?php echo $detailPetugas['foto'] ?>" width="200" alt="">
    </div>
    
    <div class="form-group">
        <label >Ganti Foto</label>
  <input class="form-control" type="file" name="foto" />
  <input type="submit" class="btn btn-primary mt-3" name="save"></input>
  <a class="btn btn-primary mt-3" href="home.php">Kembali</a>
  </form>
</div>
    </div>

    <?php
    if (isset($_POST['save']))
    {
        $namafoto=$_FILES['foto']['name'];
        $lokasifoto = $_FILES['foto']['tmp_name'];
        // jika foto dirubah
        if(!empty($lokasifoto)) {
            move_uploaded_file($lokasifoto, "foto_produk/$namafoto");
            $koneksi->query("UPDATE pengaduan SET isi_laporan = '$_POST[isi_laporan]',foto='$namafoto' WHERE id_pengaduan = '$_GET[id]'");
        } else {
            $koneksi->query("UPDATE pengaduan SET isi_laporan = '$_POST[isi_laporan]'");
        }
    
        echo "<script>alert('Laporan telah diubah');</script>";
        echo "<script>location='home.php';</script>";
    }
        
    
    
    ?>
    <script src="bootstrap-5.3.2-dist/js/bootstrap.bundle.js"></script>
    <script src="bootstrap-5.3.2-dist/bootstrap.bundle.min.js"></script>
</body>
</html>