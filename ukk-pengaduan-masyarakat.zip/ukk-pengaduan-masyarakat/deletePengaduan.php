<?php
include('koneksi.php');
 $ambil = $koneksi->query("SELECT * FROM pengaduan WHERE id_pengaduan='$_GET[id]'");
 $pecah = $ambil->fetch_assoc();
 $fotoproduk = $pecah['foto'];
  if (file_exists("foto_produk/$fotoproduk"))
  {
    unlink("foto_produk/$fotoproduk");
  }

  $koneksi->query("DELETE FROM pengaduan WHERE id_pengaduan='$_GET[id]'");

  echo "<script>alert('laporan telah dihapus');</script>";
  echo "<script>location='home.php';</script>";


?>