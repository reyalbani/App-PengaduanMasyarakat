<?php 
$koneksi = new mysqli ("localhost","root","","pengaduan_masyarakat"); 
?>