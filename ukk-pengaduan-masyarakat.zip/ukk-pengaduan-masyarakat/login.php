<?php
session_start();
//skrip koneksi
include 'koneksi.php';
?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="petugas/assets/login/fonts/icomoon/style.css">

    <link rel="stylesheet" href="petugas/assets/login/css/owl.carousel.min.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="petugas/assets/login/css/bootstrap.min.css">
    
    <!-- Style -->
    <link rel="stylesheet" href="petugas/assets/login/css/style.css">
    <link rel="stylesheet" href="style.css">

    <title>Login Laporan Pengaduan Masyarakat</title>
  </head>
  <body>
  

  <div class="d-lg-flex half">
    <div class="bg order-1 order-md-2" style="background-image: url('petugas/assets/login/images/bg_1.jpg');"></div>
    <div class="contents order-2 order-md-1">

      <div class="container">
        <div class="row align-items-center justify-content-center">
          <div class="col-md-7">
            <h3>Login to <strong>Pengaduan Masyarakat</strong></h3>
            <p class="mb-4">Satu-satunya cara untuk melakukan pekerjaan hebat yaitu dengan mencintai apa yang sedang kamu lakukan</p>
            <form action="#" method="post">
              <div class="form-group first">
                <label for="username">Username</label>
                <input type="text" class="form-control" placeholder="Username Anda" id="username" name="nama">
              </div>
              <div class="form-group last mb-3">
                <label for="password">Password</label>
                <input type="password" class="form-control" placeholder="Password Anda" id="password" name="pass">
              </div>
              
              <div class="d-flex mb-1 align-items-center">
                <!-- <label class="control control--checkbox mb-0"><span class="caption">Remember me</span> -->
                  <!-- <input type="checkbox" checked="checked"/> -->
                  <!-- <div class="control__indicator"></div> -->
                </label>
                <!-- <span class="ml-auto"><a href="#" class="forgot-pass">Forgot Password</a></span>  -->
              </div>

              <input type="submit" value="Masuk" class="btn btn-block btn-primary" name="login">

            </form>
            <a class="mt-3 btn btn-block" href="register.php">Mendaftar Akun</a>
            <?php
                                     if (isset($_POST['login']))
                                     {
                                       $ambil = $koneksi->query("SELECT * FROM user WHERE username='$_POST[nama]'
                                       AND password = '$_POST[pass]'");
                                       $yangcocok = $ambil->num_rows;
                                            
                                       if ($yangcocok > 0)
                                       {
                                             // anda sudah login
                                            $akun = $ambil->fetch_assoc();
                                            // simpan di session pelanggan
                                            $_SESSION['user'] = $akun;
                                            echo "<div class='alert alert-info mt-3'>Login sukses</div>";
                                            echo "<meta http-equiv='refresh' content='1;url=home.php'>";
                                            // jika sudah belanja
                                            // if (isset($_SESSION['keranjang']) OR !empty($_SESSION['keranjang'])) {
                                            // echo "<script>location='checkout.php';</script>";
                                       }
                                       else
                                       {
                                        echo "<div class='alert alert-danger'>Login Gagal</div>";
                                        echo "<meta http-equiv='refresh' content='1;url=login.php'>";
                                       }
                                     }
                                    
                                    ?>
          </div>
        </div>
      </div>
    </div>

    
  </div>
    
    

    <script src="petugas/assets/login/js/jquery-3.3.1.min.js"></script>
    <script src="petugas/assets/login/js/popper.min.js"></script>
    <script src="petugas/assets/login/js/bootstrap.min.js"></script>
    <script src="petugas/assets/login/js/main.js"></script>
  </body>
</html>

